function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let fazendeiro;
let flores = [];
let plantas=[];
let insetos = [];
let vidas = 2;
let pontuacao = 0;

// Emojis para as flores e insetos
const  emojiFlor  =  '🌽';
const emojiPlanta= '🫛';
const emojiInseto = '👾';

function setup() {
  createCanvas(800, 600);

  // Posição inicial do fazendeiro
  fazendeiro = {
    x: width / 2,
    y: height / 2,
    size: 50
  };

  // Criar algumas flores aleatórias
  for (let i = 0; i < 10; i++) {
    flores.push({
      x: random(20, width - 20),
      y: random(height / 2 - 50, height - 20),
      size: 40, // tamanho do emoji
      colhido: false
    });
  }

  // Criar alguns insetos
  for (let i = 0; i < 5; i++) {
    insetos.push({
      x: random(0, width),
      y: random(0, height / 2),
      size: 40, // tamanho do emoji
      speedX: random([-2, 2]),
      speedY: random([-2, 2])
    });
  }
}

function draw() {
  background(135, 206, 235); // Cor do céu

  // Desenhar o campo (grama)
  fill(34, 139, 34);
  noStroke();
  rect(0, height / 2, width, height / 2);

  // Movimento do fazendeiro
  if (keyIsDown(87)) { // W
    fazendeiro.y -= 2;
  }
  if (keyIsDown(83)) { // S
    fazendeiro.y += 2;
  }
  if (keyIsDown(65)) { // A
    fazendeiro.x -= 2;
  }
  if (keyIsDown(68)) { // D
    fazendeiro.x += 2;
  }

  // Limitar o personagem aos limites da tela
  fazendeiro.x = constrain(fazendeiro.x, fazendeiro.size / 2, width - fazendeiro.size / 2);
  fazendeiro.y = constrain(fazendeiro.y, fazendeiro.size / 2, height - fazendeiro.size / 2);

  // Desenhar o fazendeiro como emoji
  textSize(fazendeiro.size);
  textAlign(CENTER, CENTER);
  fill(0);
  text('👩‍🌾', fazendeiro.x, fazendeiro.y);

  // Desenhar e atualizar flores com emojis
  textSize(40);
  for (let i = 0; i < flores.length; i++) {
    let flor = flores[i];
    if (!flor.colhido) {
      fill(255);
      text(emojiFlor, flor.x, flor.y);
      // Verificar colisão com o fazendeiro
      if (dist(fazendeiro.x, fazendeiro.y, flor.x, flor.y) < (fazendeiro.size + flor.size) / 2) {
        flor.colhido = true;
        pontuacao++;
      }
    }
  }

  // Desenhar e atualizar insetos com emojis
  textSize(40);
  fill(0);
  for (let i = 0; i < insetos.length; i++) {
    let inseto = insetos[i];
    text(emojiInseto, inseto.x, inseto.y);
    // Movimento simples
    inseto.x += inseto.speedX;
    inseto.y += inseto.speedY;
    // Rebotar nas bordas
    if (inseto.x < inseto.size / 2 || inseto.x > width - inseto.size / 2) {
      inseto.speedX *= -1;
    }
    if (inseto.y < inseto.size / 2 || inseto.y > height - inseto.size / 2) {
      inseto.speedY *= -1;
    }
    // Verificar colisão com o fazendeiro
    if (dist(fazendeiro.x, fazendeiro.y, inseto.x, inseto.y) < (fazendeiro.size + inseto.size) / 2) {
      vidas--;
      // Reposicionar o inseto para evitar múltiplas colisões seguidas
      inseto.x = random(0, width);
      inseto.y = random(0, height / 2);
    }
  }

  // Mostrar vidas e pontuação
  fill(0);
  textSize(20);
  textAlign(LEFT, TOP);
  text(`Vidas: ${vidas}`, 10, 10);
  text(`Pontuação: ${pontuacao}`, 10, 40);

  // Verificar se o jogo acabou
  if (vidas <= 0) {
    noLoop();
    fill(0);
    textSize(50);
    textAlign(CENTER, CENTER);
    text('Game Over', width / 2, height / 2);
    
    // Verificar se todas as flores foram colhidas
    const todasColhidas = flores.every(flor => flor.colhido);
    if (todasColhidas) {
      text('Parabéns!', width / 2, height / 2 + 60);
    } else {
      text('Você perdeu', width / 2, height / 2 + 60);
    }
  }

  // Caso o jogo não tenha acabado, verificar se todas as flores foram colhidas
  if (flores.every(flor => flor.colhido) && vidas > 0) {
    noLoop();
    fill(0);
    textSize(50);
    textAlign(CENTER, CENTER);
    text('Parabéns graças a você o Fazendeiro conseguiu colher seus milhos para vender na cidade 🎊🎉✨!', width / 2, height / 2);
  }
}
